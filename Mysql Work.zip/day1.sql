-- DAY 1

-- create a db
CREATE DATABASE myDB;
CREATE DATABASE myDB;

-- drop a schema
DROP DATABASE mydb;

/* either dbl click or run below commond
to use a particular db */
USE mydb;

-- to alter permission 
-- ALTER DATABASE mydb READ ONLY = 0;

-- can't drop a db
DROP DATABASE mydb;

-- create a table
CREATE TABLE tb1 (
	name char(100)
);

CREATE TABLE book(
	title VARCHAR(30),
    publication_year YEAR,
    updated_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    genre VARCHAR(10),
    isbn SMALLINT(13)
);

-- create a table having same field from existing table (Inheritence)
CREATE TABLE papers
	AS SELECT 
	title, publication_year
    FROM book;

-- renaming a table
RENAME TABLE book TO BOOKS;

-- droping a table
DROP TABLE Books;

-- altering table

-- add
ALTER TABLE book
	ADD price DECIMAL(5, 2);

ALTER TABLE tb1 
	ADD (f1 int, f2 int);
    
-- drop
ALTER TABLE tb1 
	DROP COLUMN f1,
    DROP COLUMN f2;
    
-- modify
ALTER TABLE book
	MODIFY COLUMN 
    price DECIMAL(7, 2); -- [5].[2] = [7]

ALTER TABLE book
	MODIFY COLUMN
    isbn VARCHAR(13);
    
-- INSERT, UPDATE, DELETE rows

-- insert default val or null if not set
INSERT INTO book () values();

-- multi-row insertion
INSERT INTO book (title, publication_year, genre, isbn, price) 
	VALUES
	('The Silent Echo', 2020, 'Mystery', '978012345678', 194.3),
	('Wings of Dawn', 2018, 'Fantasy', '978012345679', 323.42);

INSERT INTO book (title, genre, price)
	VALUES
    ('The giving tree', 'Inspire', 100);

INSERT INTO book
	SET title = 'Demo';

CREATE TABLE old_book
	AS SELECT title, publication_year
    FROM book;
    
TRUNCATE TABLE old_book;

INSERT INTO old_book
	SELECT title, publication_year 
    FROM book
    WHERE publication_year < 2020 OR publication_year is NULL;

UPDATE book
	SET publication_year = 2000, price = price - price*0.5
    WHERE publication_year is NULL OR publication_year < 2020;
    
-- constarint

-- add unique constr. by altering tbl
ALTER TABLE book
	ADD CONSTRAINT 
    unique_isbn UNIQUE (isbn);

ALTER TABLE book
	MODIFY updated_on VARCHAR(30) NOT NULL;

ALTER TABLE book
	MODIFY updated_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
    
ALTER TABLE book
	DROP PRIMARY KEY;

ALTER TABLE book
	ADD CONSTRAINT
    pk_book PRIMARY KEY(isbn);

CREATE TABLE author(
	author_id int AUTO_INCREMENT,
	first_name VARCHAR(10) NOT NULL,
    last_name VARCHAR(10),
    CONSTRAINT pk_author PRIMARY KEY (author_id)
);

INSERT INTO author
    set first_name = 'Mary';

ALTER TABLE book
	ADD author_id INT;

ALTER TABLE book
	ADD CONSTRAINT
    fk_author_book FOREIGN KEY(author_id)
    REFERENCES author(author_id);
    
