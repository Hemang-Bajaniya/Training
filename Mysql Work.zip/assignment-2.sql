-- Assignment 2

use studentdb;

CREATE TABLE subjects (
    subject_id INT PRIMARY KEY AUTO_INCREMENT,
    subject_name VARCHAR(100) NOT NULL UNIQUE,
    course_id INT,
    FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

-- Assignment 6: Subqueries
-- 1.	Find students who scored above the average score using a subquery.
SELECT 
    name, m.subject_id
FROM
    students s
INNER JOIN
    marks m 
ON 
	s.student_id = m.student_id
WHERE
    m.score > (
		SELECT 
            AVG(score)
        FROM
            marks
        WHERE
			subject_id = m.subject_id
);
            
-- 2.	Get students enrolled in the same course as “John” using a correlated subquery.
select name from students s
where s.course_id in (select distinct course_id from students where name like "Jhon%")
and name not like "Jhon%";

-- Assignment 7: UNION & Set Ops

-- 1.	Write a query to list all distinct course names from Courses and Marks tables (use UNION).
select course_name as "course & subject names" from courses 
union
select subject_name from subjects;

-- 2.	Write another query to include duplicates (use UNION ALL).
select course_name as "course & subject names" from courses 
union all
select subject_name from subjects;

-- Assignment 8: Constraints & Performance
-- 1.	Add a PRIMARY KEY on student_id.
ALTER TABLE students
ADD CONSTRAINT pk_students PRIMARY KEY (student_id);

-- 2.	Add an AUTO_INCREMENT to course_id.
ALTER TABLE courses
MODIFY COLUMN
	course_id INT AUTO_INCREMENT;

-- 3.	Create an INDEX on email for faster search.
CREATE FULLTEXT INDEX email_ft_idx ON students(email);

-- 4.	Prove query optimization difference using EXPLAIN with and without index.
EXPLAIN SELECT * from students WHERE email LIKE '%gmail.com'; -- not work
EXPLAIN SELECT * FROM students WHERE MATCH(email) AGAINST('gmail.com');


-- Assignment 9: Stored Programs
-- 1.	Write a Stored Procedure to return all students enrolled in a given course.

delimiter //
CREATE PROCEDURE studentsInCourses(IN p_courseName VARCHAR(20))
BEGIN
	SELECT name FROM students
	WHERE
		course_id = (SELECT course_id from courses
            WHERE
				course_name = p_courseName);
END //
delimiter ;

CALL studentsInCourses("Web Development");

-- 2.	Create a Function to calculate grade based on marks (e.g., A/B/C).
SET GLOBAL log_bin_trust_function_creators = 1;
delimiter //
CREATE FUNCTION CalculateGrades (p_student_id INT)
RETURNS VARCHAR(5)
BEGIN
	DECLARE v_avgMarks DECIMAL(5,2); 
    
    SELECT AVG(score) INTO v_avgMarks
    FROM
		marks
	WHERE student_id = p_student_id;
	
    RETURN
    CASE
		WHEN v_avgMarks > 75 THEN 'A'
        WHEN v_avgMarks > 60 THEN 'B'
        ELSE 'C'
    END;
END//
delimiter ;

DROP FUNCTION CalculateGrades;

SELECT name, CalculateGrades(student_id) as "Grade"
FROM
	students
ORDER BY Grade;

-- 3.	Create a Trigger to log deleted student records into a new table DeletedStudents.
CREATE TABLE deletedstudents AS
SELECT * 
FROM
	students;
    
TRUNCATE deletedstudents;

ALTER TABLE deletedstudents
ADD COLUMN deletedon TIMESTAMP DEFAULT CURRENT_TIMESTAMP;

delimiter //
CREATE TRIGGER logDeleteStudent_trigger
AFTER DELETE
ON students
FOR EACH ROW
BEGIN
	INSERT INTO deletedstudents(student_id, name, course_id, gender, dob, email)
    VALUES
		(old.student_id, old.name, old.course_id, old.gender, old.dob, old.email);
END //
delimiter ;

DROP TRIGGER logDeleteStudent_trigger;

DELETE FROM students WHERE student_id = 7;

UPDATE marks
set score = score - (score*0.1) WHERE student_id in (1,5,3);