-- Project
use payroll;

CREATE TABLE employees(
    emp_id INT AUTO_INCREMENT,
    name VARCHAR(20),
    dept_id INT,
    salary DECIMAL(7, 2),
    CONSTRAINT pk_employee PRIMARY KEY(emp_id),
    CONSTRAINT fk_employee_dept FOREIGN KEY (dept_id) REFERENCES departments(dept_id)
);

CREATE TABLE departments(
    dept_id INT AUTO_INCREMENT,
    dept_name VARCHAR(15),
    CONSTRAINT pk_dept PRIMARY KEY(dept_id)
);

CREATE TABLE salaries(
    emp_id INT,
    MONTH DATE,
    amount DECIMAL(7, 2),
    CONSTRAINT fk_salary_employee FOREIGN KEY(emp_id) REFERENCES employees(emp_id)
);

ALTER TABLE
    salaries MODIFY COLUMN amount DECIMAL(7, 2);
    
-- Tasks
WITH emp_avg_sal AS (
    SELECT
        emp_id,
        AVG(amount) AS "avg_sal"
    FROM
        salaries
    GROUP BY
        emp_id
)
SELECT
    e.name,
    d.dept_name,
    es.avg_sal
FROM
    employees e
    LEFT OUTER JOIN departments d ON e.dept_id = d.dept_id
    LEFT JOIN emp_avg_sal es ON e.emp_id = es.emp_id;
SELECT
    e.name,
    e.salary,
    d.dept_name
FROM
    employees e
    LEFT OUTER JOIN departments d ON e.dept_id = d.dept_id
WHERE
    e.salary > (
        SELECT
            AVG(salary)
        FROM
            employees es
        WHERE
            es.dept_id = e.dept_id
    );
    
delimiter // 
CREATE PROCEDURE CalcYearlySalary(IN p_emp_id INT) BEGIN
SELECT
    e.emp_id,
    e.name,
    d.dept_name,
    YEAR(s.month) AS YEAR,
    SUM(s.amount) AS yearly_salary
FROM
    employees e
    JOIN salaries s ON e.emp_id = s.emp_id
    JOIN departments d ON e.dept_id = d.dept_id
WHERE
    e.emp_id = p_emp_id
GROUP BY
    e.emp_id,
    e.name,
    d.dept_name,
    YEAR(s.month);
END //
delimiter;

DROP PROCEDURE CalcYearlySalary;

CALL CalcYearlySalary(1);

CREATE TABLE salarylog AS
SELECT
    emp_id,
    MONTH,
    amount
FROM
    salaries;
truncate salarylog;
ALTER TABLE
    salarylog
ADD
    COLUMN updated_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP;

delimiter // 
CREATE TRIGGER LogSalryInsertion after INSERT ON salaries FOR EACH ROW BEGIN
INSERT INTO
    salarylog(emp_id, MONTH, amount)
VALUES
(NEW.emp_id, NEW.month, NEW.amount);
END // 
delimiter;

DROP TRIGGER LogSalryInsertion;
INSERT INTO
    salaries (emp_id, MONTH, amount)
VALUES
    (1, '2025-09-01', 4500),
    (2, '2025-09-01', 5200.00),
    (3, '2025-09-01', 6000.00);
SELECT
    *
FROM
    salarylog;
SELECT
    emp_id
FROM
    employees
WHERE
    emp_id IN (1, 2, 3);

CREATE VIEW employee_salary_summary_by_year AS
SELECT
    emp_id,
    YEAR(MONTH) AS salary_year,
    COUNT(*) AS months_recorded,
    SUM(amount) AS total_salary,
    AVG(amount) AS avg_monthly_salary
FROM
    payroll.salaries
GROUP BY
    emp_id,
    YEAR(MONTH);
    
SELECT
    *
FROM
    employee_salary_summary_by_year;