-- DAY 1

-- create a db
CREATE DATABASE myDB;
CREATE DATABASE myDB;

-- drop a schema
DROP DATABASE mydb;

/* either dbl click or run below commond
to use a particular db */
USE mydb;


-- to alter permission 
-- ALTER DATABASE mydb READ ONLY = 0;

-- can't drop a db
DROP DATABASE mydb;

-- create a table
CREATE TABLE tb1 (
	name char(100)
);

CREATE TABLE book(
	title VARCHAR(30),
    publication_year YEAR,
    updated_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    genre VARCHAR(10),
    isbn SMALLINT(13)
);

-- create a table having same field from existing table (Inheritence)
CREATE TABLE papers
	AS SELECT 
	title, publication_year
    FROM book;

-- renaming a table
RENAME TABLE books TO book;

-- droping a table
DROP TABLE Books;

-- altering table

-- add
ALTER TABLE book
	ADD price DECIMAL(5, 2);

ALTER TABLE tb1 
	ADD (f1 int, f2 int);
    
-- drop
ALTER TABLE tb1 
	DROP COLUMN f1,
    DROP COLUMN f2;
    
-- modify
ALTER TABLE book
	MODIFY COLUMN 
    price DECIMAL(7, 2); -- [5].[2] = [7]

ALTER TABLE book
	MODIFY COLUMN
    isbn VARCHAR(13);
    
-- INSERT, UPDATE, DELETE rows

-- insert default val or null if not set
INSERT INTO book () values();

-- multi-row insertion
INSERT INTO book (title, publication_year, genre, isbn, price) 
	VALUES
	('The Silent Echo', 2020, 'Mystery', '978012345678', 194.3),
	('Wings of Dawn', 2018, 'Fantasy', '978012345679', 323.42);

INSERT INTO book (title, genre, price)
	VALUES
    ('The giving tree', 'Inspire', 100);

INSERT INTO book
	SET title = 'Demo';

CREATE TABLE old_book
	AS SELECT title, publication_year
    FROM book;
    
TRUNCATE TABLE old_book;

INSERT INTO old_book
	SELECT title, publication_year 
    FROM book
    WHERE publication_year < 2020 OR publication_year is NULL;

UPDATE book
	SET publication_year = 2000, price = price - price*0.5
    WHERE publication_year is NULL OR publication_year < 2020;
    
-- constarint

-- add unique constr. by altering tbl
ALTER TABLE book
	ADD CONSTRAINT 
    unique_isbn UNIQUE (isbn);

ALTER TABLE book
	MODIFY updated_on VARCHAR(30) NOT NULL;

ALTER TABLE book
	MODIFY updated_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
    
ALTER TABLE book
	DROP PRIMARY KEY;

ALTER TABLE book
	ADD CONSTRAINT
    pk_book PRIMARY KEY(isbn);

CREATE TABLE author(
	author_id int AUTO_INCREMENT,
	first_name VARCHAR(10) NOT NULL,
    last_name VARCHAR(10),
    CONSTRAINT pk_author PRIMARY KEY (author_id)
);

INSERT INTO author
    set first_name = 'Mary';

ALTER TABLE book
	ADD author_id INT;

ALTER TABLE book
	ADD CONSTRAINT
    fk_author_book FOREIGN KEY(author_id)
    REFERENCES author(author_id) ON DELETE SET NULL;

ALTER TABLE book
	DROP CONSTRAINT fk_author_book;


-- select
SELECT * FROM book;

INSERT INTO author (first_name, last_name) VALUES
('John', 'Doe'),
('Jane', 'Smith'),
('Alice', 'Brown'),
('Bob', 'Johnson'),
('Emma', 'Davis'),
('Mark', 'Wilson');

INSERT INTO book (title, publication_year, genre, isbn, price, author_id) VALUES
('The Lost Tale', 2015, 'Fantasy', '9781234567890', 19.99, 1),
('Code of Life', 2020, 'Sci-Fi', '9780987654321', 24.50, 2),
('Mystery Manor', 2018, 'Mystery', '9781112223334', 15.75, 2),
('Love Eternal', 2022, 'Romance', '9784445556667', 12.99, 3),
('Tech World', 2019, 'Tech', '9787778889990', 29.99, NULL),
('Dark Secrets', 2017, 'Mystery', '9782223334445', 18.25, 4),
('Star Journey', 2023, 'Sci-Fi', '9785556667778', 22.00, 5),
('Poetry Bliss', 2021, 'Poetry', '9788889990001', 14.99, NULL);

-- all diff genre
SELECT DISTINCT genre 
	FROM 
	book;

-- num comparison
SELECT title 
	FROM 
    book
	WHERE price > 22;

SELECT title 
	FROM 
    book
	WHERE 
    price BETWEEN 14 AND 16;

SELECT * 
	from 
    book
	WHERE 
    genre = 'Mystery'
    AND publication_year >= 2019;

SELECT title, publication_year 
	FROM 
	book
	ORDER BY 
    publication_year DESC;
 
SELECT title, publication_year, price 
	FROM 
	book
	ORDER BY 
    publication_year, price DESC;

SELECT title, timestampdiff(year, publication_year, year()) as years 
	FROM 
    book;

SELECT genre, author_id, count(*) 
	FROM 
	book
	GROUP BY genre, author_id;





-- Meeting 2 --------------------------------------------------------

-- dcl
CREATE USER 'reader'@'localhost'
	IDENTIFIED BY 'password';

GRANT CREATE 
ON
	mydb.*
TO
	'reader'@'localhost';

ALTER USER 'root'@'localhost'
IDENTIFIED BY
	'root';

SHOW GRANTS
FOR
	'reader'@'localhost';
	
REVOKE INSERT
ON
	mydb.book
FROM	
	'reader'@'localhost';
 
-- joins

-- inner join
SELECT a.first_name, b.title, b.price
FROM 
	book as b
INNER JOIN
	author as a
ON
	b.author_id = a.author_id;

-- outer join
-- left outer - all the data from left table if not avl in right gie null in col
SELECT a.first_name, b.author_id, a.author_id, b.title
FROM 
	book as b
LEFT OUTER JOIN
	author as a
ON
	b.author_id = a.author_id;

-- right join
SELECT a.first_name, a.author_id as "Author pk id", b.author_id, b.title
FROM 
	book as b
RIGHT OUTER JOIN
	author as a
ON
	b.author_id = a.author_id;

-- self join
-- for each book return all the books having price more than that book
SELECT b1.title, b1.price, b2.title, b2.price
FROM
	book b1
JOIN
	book b2
ON 
	b1.price < b2.price
ORDER BY
	b1.price;

-- moving tables dbs
ALTER TABLE 
	studentdb.author
RENAME TO
	mydb.author;

ALTER TABLE 
	studentdb.book
RENAME TO
	mydb.book;

-- joining multi-tables
CREATE TABLE publisher (
  publisher_id int NOT NULL AUTO_INCREMENT,
  publisher_name varchar(50) NOT NULL,
  city varchar(30) DEFAULT NULL,
  PRIMARY KEY (publisher_id)
);

CREATE TABLE book_sale (
  sale_id int NOT NULL AUTO_INCREMENT,
  book_id varchar(13) DEFAULT NULL,
  sale_date date DEFAULT NULL,
  quantity int DEFAULT NULL,
  total_amount decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (sale_id),
  KEY fk_book_sale (book_id),
  CONSTRAINT fk_book_sale FOREIGN KEY (book_id) REFERENCES book (isbn) ON DELETE SET NULL
);

INSERT INTO publisher (publisher_name, city) VALUES
('Penguin Books', 'New York'),
('Random House', 'London'),
('HarperCollins', 'Toronto'),
('Bloomsbury', 'Sydney'),
('Simon & Schuster', 'Boston');

-- added pub_id to book
ALTER TABLE book
ADD COLUMN publisher_id int DEFAULT NULL,
ADD CONSTRAINT fk_book_publisher FOREIGN KEY (publisher_id) REFERENCES publisher (publisher_id) ON DELETE SET NULL;

-- set book table with pub_id
UPDATE book SET publisher_id = 1 WHERE isbn = '9781234567890'; 
UPDATE book SET publisher_id = 2 WHERE isbn = '9780987654321'; 
UPDATE book SET publisher_id = 2 WHERE isbn = '9781112223334'; 
UPDATE book SET publisher_id = 3 WHERE isbn = '9784445556667'; 
UPDATE book SET publisher_id = 4 WHERE isbn = '9787778889990';
UPDATE book SET publisher_id = 1 WHERE isbn = '9782223334445';
UPDATE book SET publisher_id = 5 WHERE isbn = '9785556667778';
UPDATE book SET publisher_id = 3 WHERE isbn = '9788889990001';

INSERT INTO book_sale (book_id, sale_date, quantity, total_amount) VALUES
('9781234567890', '2025-01-15', 5, 99.95),
('9780987654321', '2025-02-20', 3, 73.50),
('9781112223334', '2025-03-10', 2, 31.50),
('9784445556667', '2025-04-05', 4, 51.96),
('9787778889990', '2025-05-12', 1, 29.99),
('9782223334445', '2025-06-18', 3, 54.75),
('9785556667778', '2025-07-22', 2, 44.00),
('9788889990001', '2025-08-30', 6, 89.94);


-- joins practice

-- Query: List all books with their authors' names, excluding books without an author.
SELECT b.title, b.author_id, concat(a.first_name, ' ', a.last_name) as name
FROM
	book b
INNER JOIN
	author a
ON
	a.author_id = b.author_id;

-- Query: List all books, including those without authors, along with author names where available.
SELECT b.title, concat(a.first_name, ' ', a.last_name) as name
FROM
	book b
LEFT OUTER JOIN
	author a
ON
	a.author_id = b.author_id;

-- Query: List all authors and their books, including authors who haven’t written any books.
SELECT b.title, concat(a.first_name, ' ', a.last_name) as name
FROM
	book b
RIGHT OUTER JOIN
	author a
ON
	a.author_id = b.author_id;
    
-- Query: List books with their authors and publishers, excluding books without authors or publishers.
SELECT b.title, a.first_name, a.last_name, p.publisher_name
FROM
	book b
INNER JOIN
	author a
ON
	b.author_id = a.author_id
INNER JOIN	
	publisher p
ON
	b.publisher_id = p.publisher_id;

SELECT a.first_name, a.last_name
FROM author a
LEFT JOIN book b ON a.author_id = b.author_id
WHERE b.isbn IS NULL;

SELECT b.title, b.isbn
FROM book b
LEFT JOIN book_sale bs ON b.isbn = bs.book_id
WHERE bs.sale_id IS NULL;

-- Query: Count the number of books written by each author, including authors with zero books.
SELECT a.first_name, count(b.isbn) as book_count
FROM
	book b
RIGHT OUTER JOIN
	author a
ON
	a.author_id = b.author_id
GROUP BY
	a.author_id
ORDER BY
	book_count;

SELECT publisher_name
FROM
	publisher
GROUP BY
	publisher.publisher_id;


SELECT
min(price)
FROM
	book;

SELECT
max(price)
FROM
	book;

SELECT genre, avg(price)
FROM
	book
GROUP BY
	genre
ORDER BY genre;

SELECT p.publisher_name, GROUP_CONCAT(b.title SEPARATOR ', ') AS book_titles
FROM publisher p
LEFT JOIN book b ON p.publisher_id = b.publisher_id
GROUP BY p.publisher_id, p.publisher_name;