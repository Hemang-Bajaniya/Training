-- Assignment 1 ---------------------------------------------------------

-- 1
CREATE DATABASE studentdb;

USE studentdb;

-- Assignment - 2 ---------------------------------------------------------

-- 1
CREATE TABLE courses(
	course_id INT AUTO_INCREMENT,
    course_name VARCHAR(20) NOT NULL,
    duration SMALLINT, -- in weeks
    CONSTRAINT pk_course PRIMARY KEY (course_id)
);

CREATE TABLE student(
	student_id INT AUTO_INCREMENT,
    name VARCHAR(30) NOT NULL,
    gender ENUM('male', 'female', 'other'),
    course_id INT,
    CONSTRAINT pk_student PRIMARY KEY (student_id),
    CONSTRAINT fk_student_course FOREIGN KEY (course_id)
		REFERENCES courses(course_id)
);

CREATE TABLE marks(
	mark_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    subject VARCHAR(15),
    score INT,
    CONSTRAINT fk_mark_student FOREIGN KEY (student_id)
		REFERENCES students(student_id)
);

RENAME TABLE student TO students;

-- 2
ALTER TABLE students
	ADD email varchar(50) CHECK (email like '%.com');

-- 3 
DROP TABLE marks;
    
    
-- Assignment 3 ---------------------------------------------------------

-- 1
INSERT INTO courses (course_name, duration) VALUES
	('Data Science', 8),
	('Web Development', 10),
	('Machine Learning', 12),
	('Database Systems', 6),
	('Cloud Computing', 9);

-- loading student data via .csv

INSERT INTO marks (student_id, subject, score) VALUES
	(1, 'Python', 85),
	(1, 'Statistics', 78),
	(2, 'HTML', 92),
	(3, 'R Programming', 88),
	(4, 'Deep Learning', 95),
	(5, 'SQL', 82),
	(6, 'JavaScript', 87);

-- 2
UPDATE students 
set 
	course_id = 2
where 
	student_id = 1;

-- 3
ALTER TABLE marks
drop CONSTRAINT 
	fk_mark_student;

ALTER TABLE marks
ADD CONSTRAINT 
	fk_mark_student
FOREIGN KEY 
	(student_id) REFERENCES students(student_id)
ON DELETE CASCADE;
-- ON DELETE set null;

DELETE FROM students
WHERE 
    student_id = 4;
    
-- Assignment 4 ---------------------------------------------------------

ALTER TABLE students
ADD 
    dob DATE;

UPDATE students
SET 
	dob = CURRENT_DATE;
    
-- 1
SELECT name, timestampdiff(year, dob, curdate()) as age 
FROM 
    students 
WHERE 
    dob IS NOT NULL and timestampdiff(year, dob, curdate()) >= 27;
    
SELECT name, abs(year(curdate()) - year(dob)) as years
from 
    students
where 
    abs(year(curdate()) - year(dob)) >= 29;


-- 2
SELECT name 
from 
    students
ORDER BY 
    name DESC;

-- 3
SELECT course_id, count(*) 
FROM 
    students
GROUP BY 
    course_id;

-- 4
SELECT course_id, count(*) 
FROM 
    students
GROUP BY 
    course_id 
HAVING 
    count(*) > 2;

-- Assignment - 5 ---------------------------------------------------------

-- 1
SELECT s.name, c.course_name
FROM
	students s
INNER JOIN
	courses c
ON
	s.course_id = c.course_id;
    
-- 2
SELECT s.name, c.course_name
FROM
	students s
LEFT OUTER JOIN
	courses c
ON
	s.course_id = c.course_id;

-- 3
SELECT s.name, c.course_name
FROM
	students s
RIGHT OUTER JOIN
	courses c
ON
	s.course_id = c.course_id;
-- WHERE s.name is null;

-- 4
SELECT subject, max(score), min(score), avg(score)
FROM
	marks
GROUP BY
	subject;

-- 5
SELECT gender, count(*)
FROM
	students
GROUP BY
	gender;
