USE mydb;

-- upsert
INSERT author
VALUES
	(10, "Mary", "Jane")
ON DUPLICATE KEY UPDATE
	first_name = "Mary",
    last_name = "Jane";

-- partition

CREATE TABLE result_partition (
    id INT AUTO_INCREMENT,
    name VARCHAR(10) NOT NULL,
    cpi DECIMAL(4,2) NOT NULL,
    cpi_int INT AS (cpi * 100) STORED,
    CONSTRAINT pk_result PRIMARY KEY (id, cpi_int)
)
PARTITION BY RANGE (cpi_int) (
    PARTITION p_fail         VALUES LESS THAN (550),   -- < 5.50
    PARTITION p_first_class  VALUES LESS THAN (750),   -- < 7.50
    PARTITION p_distinction  VALUES LESS THAN MAXVALUE
);

SELECT * FROM
	result_partition
WHERE
	cpi_int < 750;
    
-- cte

-- named query, reusable
WITH expensive_books AS(
SELECT
	title, isbn, price
FROM
	book WHERE price > 20
)
SELECT * FROM -- main query
	book_sale bs
INNER JOIN
	expensive_books eb
ON
	bs.book_id = eb.isbn
ORDER BY
	eb.title;
    
WITH auth_avg AS (
SELECT concat(a.first_name, ' ', a.last_name), avg(b.price) as avg_price
FROM
	author a
INNER JOIN
	book b
ON
	a.author_id = b.author_id
GROUP BY 
	a.author_id
)
SELECT * FROM auth_avg
WHERE
	avg_price >= 20;

SELECT b.title, a.first_name, a.last_name, p.publisher_name
FROM book b
INNER JOIN author a ON b.author_id = a.author_id
INNER JOIN publisher p ON b.publisher_id = p.publisher_id;

WITH book_author_info AS (
	SELECT b.isbn, b.title, a.first_name as auth_name, b.publisher_id
	FROM
		book b
	INNER JOIN
		author a
	ON
		a.author_id = b.author_id
)
SELECT bai.title, bai.auth_name, p.publisher_name
FROM
	book_author_info bai
INNER JOIN
	publisher p
ON
	bai.publisher_id = p.publisher_id;

-- limit
-- offset
SELECT title, price
FROM
	book
ORDER BY
	price DESC;

-- 2 exp book
SELECT title, price
FROM
	book
ORDER BY
	price DESC
LIMIT 1, 1;

-- cascade

-- case
SELECT isbn, 
CASE
	WHEN isbn%2 = 0 THEN "Even"
    ELSE "Odd"
END AS "odd_or_even"
FROM
	book;

-- custom search high, med but with title
SELECT title, price
FROM book
ORDER BY
   CASE
       WHEN price >= 20 THEN 1
       WHEN price BETWEEN 15 AND 20 THEN 2
       ELSE 3
   END, title;


-- nested q
SELECT title, price, genre
FROM
	book
WHERE 
	price > (SELECT avg(price) FROM book GROUP BY genre HAVING genre = "Mystery");
    
WITH genre_avg_price as(
SELECT avg(price), genre
FROM
	book
GROUP BY 
	genre
)
SELECT title, price, genre
FROM
	book
WHERE price BETWEEN 
	(SELECT avg(price) FROM book
	GROUP BY genre HAVING genre = "Mystery") 
AND
	(SELECT avg(price) FROM book
	GROUP BY genre HAVING genre = "Sci-Fi");
    
-- Find authors who have at least one book.
SELECT first_name, last_name
FROM author
WHERE author_id IN (SELECT DISTINCT author_id FROM book);

-- book not sold yet
SELECT title, isbn
FROM
	book b
WHERE NOT EXISTS(
	SELECT 1 FROM 
		book_sale bs
	WHERE
		b.isbn = bs.book_id
);

-- corealted
SELECT title, publisher_id, price
FROM 
	book b1
WHERE 
	price = (SELECT max(price)
    FROM
		book b2
	WHERE 
		b1.publisher_id = b2.publisher_id
)
ORDER BY price DESC LIMIT 1,1;

-- book grt price specific author
SELECT title, price
FROM book
WHERE price > ALL (
    SELECT price
    FROM book
    WHERE author_id = 2
);

-- prac

-- Q1. Find books that are more expensive than the average price of all books.
SELECT title, price
FROM
	book
WHERE
	price > (SELECT
    avg(price)
    FROM
		book);
			
-- Q2. Find authors who have written at least one book.
SELECT concat(first_name, ' ', last_name) as name
FROM
	author a
WHERE
	a.author_id IN( SELECT DISTINCT author_id
    FROM
		book);
    
-- Q3. List publishers who have published books.
SELECT publisher_name
FROM publisher p
WHERE EXISTS (
    SELECT 1 
    FROM book b 
    WHERE b.publisher_id = p.publisher_id
);

-- Q4. Find the most expensive book for each publisher.
SELECT b.title, b.price, p.publisher_name
FROM 
	book b
INNER JOIN
	publisher p
ON
	b.publisher_id = p.publisher_id
WHERE 
	b.price = ( SELECT max(price)
    FROM
		book b2
	WHERE
		b2.publisher_id = p.publisher_id);

-- Q5. Show each author with the number of books they have written (without using JOIN).
SELECT concat(first_name, ' ', last_name) as name,
(SELECT count(*)
FROM
	book
WHERE
	book.author_id = author.author_id
) as book_count FROM author;

-- Q6. Find books that sold more than the average sales quantity.
SELECT b.title, bs.quantity
FROM book_sale bs
JOIN book b ON bs.book_id = b.isbn
WHERE bs.quantity > (
    SELECT AVG(quantity) FROM book_sale
);

-- Find authors who haven’t written any book. (Hint: NOT IN or NOT EXISTS).
SELECT concat(first_name, ' ', last_name) as name
FROM
	author a
WHERE
	a.author_id NOT IN( SELECT DISTINCT author_id
    FROM
		book
	WHERE
		author_id is NOT NULL);
        
-- Find books that are priced higher than all books of author “John Doe” (Hint: ALL).
SELECT b.title, b.price
FROM 
	book b
WHERE
	price > ALL (SELECT price
    FROM
		book
	WHERE author_id = (
    SELECT author_id 
    FROM
		author
	WHERE
		concat(first_name, ' ', last_name) = "John Doe")
);
    
-- Show each publisher with the average book price (use subquery in FROM).
SELECT p.publisher_name, (
SELECT avg(price)
FROM
	book b
WHERE
	b.publisher_id = p.publisher_id
) as avg_book_price
FROM
	publisher p;
    
-- set op
WITH pub_info AS(
SELECT publisher_id 
FROM
	book
WHERE
	price > 20
UNION
SELECT publisher_id
FROM
	publisher
WHERE
	city = 'New York')
SELECT p.publisher_name
FROM
	publisher p
INNER JOIN
	pub_info pi
on
	pi.publisher_id = p.publisher_id;

-- Q1. List all names (authors and publishers) without duplicates.
SELECT concat(first_name, ' ', last_name) as author_name
FROM
	author
UNION ALL
SELECT publisher_name as name
FROM
	publisher as name;

-- Q3. Find authors who have written at least one book.
SELECT concat(first_name, ' ', last_name) as author_name
FROM
	author
WHERE 
	author_id IN(
    SELECT DISTINCT(author_id)
    FROM
		book
);

SELECT genre FROM book
UNION
SELECT genre FROM old_book;

-- Find all names (authors + publishers) but exclude those publishers who haven’t published any books.
SELECT	concat(first_name, ' ', last_name) as author_publisher_name
FROM
	author
UNION
SELECT publisher_name
FROM
	publisher p
WHERE EXISTS(
	SELECT 1 FROM
		book b
    WHERE
		b.publisher_id = p.publisher_id);

-- triggers
CREATE TABLE book_activity(
	id int AUTO_INCREMENT,
    book_id VARCHAR(13),
    action ENUM('Insert', 'Update', 'Delete'),
    time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT pk_book_activity PRIMARY KEY (id),
    CONSTRAINT fk_book_book_activity FOREIGN KEY (book_id) REFERENCES book(isbn)
);

DELIMITER $$
CREATE TRIGGER book_activity_trigger
AFTER INSERT ON
	book
FOR EACH ROW
BEGIN
	INSERT INTO book_activity(book_id, action)
    VALUES(new.isbn, 'Insert');
END $$ 
DELIMITER ;

DROP TRIGGER book_activity_trigger;

INSERT INTO book (title, publication_year, genre, isbn, price, publisher_id) 
	VALUES
	('Spider-Man', 2025, 'Comics', '978012945678', 200.25, 1);

INSERT INTO book (title, publication_year, genre, isbn, price, publisher_id) 
	VALUES
	('Lokah', 2017, 'Fantasy', '978010945678', 234.45, 2),
    ('Chakra', 2007, 'Comics', '926012945678', 156.68, 2);

-- Prevent deletion of an author who has books
DELIMITER $$
CREATE TRIGGER handlebook_deletion_trigger
BEFORE DELETE ON
	author
FOR EACH ROW
BEGIN
	IF old.author_id IN(SELECT DISTINCT author_id FROM book) THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Author having at least one book can\'t be deleted';
	END IF;
END$$
DELIMITER ;

DELETE FROM author WHERE author_id = 1;

CREATE TABLE publisher_stats (
    publisher_id INT PRIMARY KEY,
    book_count INT DEFAULT 0,
    CONSTRAINT fk_publisher_stat FOREIGN KEY (publisher_id) REFERENCES publisher(publisher_id)
);


-- track bok sold
DELIMITER $$
CREATE TRIGGER pub_book_sold_trigger
AFTER INSERT ON
	book
FOR EACH ROW
BEGIN
	INSERT INTO publisher_stats VALUES(
		new.publisher_id, 1)
	ON DUPLICATE KEY UPDATE
		book_count = book_count + 1;
END $$
DELIMITER ;

INSERT INTO publisher_stats
SELECT
	publisher_id, 0
FROM
	book
WHERE
	publisher_id IS NOT NULL
ON DUPLICATE KEY UPDATE
	book_count = book_count + 1;
    
-- var
SET @name = (SELECT price from book where isbn = "1");
SELECT @name;
    
-- calc total_amount
DELIMITER $$
CREATE TRIGGER calc_total_amount_trigger
BEFORE INSERT ON
	book_sale
FOR EACH ROW
BEGIN
	DECLARE v_book_price DECIMAL(5.2);
    
    set v_book_price := (SELECT price FROM book WHERE book.isbn = new.book_id);
    
    SET new.total_amount = new.quantity * v_book_price;
END $$
DELIMITER ;

DROP TRIGGER calc_total_amount_trigger;

-- sp

-- 1. Get all books of a given author
delimiter //
CREATE PROCEDURE GetAllBooksByAuthor(IN p_authorName VARCHAR(50))
BEGIN
	SELECT b.title, b.genre, b.price
    FROM
		book b
	INNER JOIN
		author a
	ON
		a.author_id = b.author_id
	WHERE
		concat(a.first_name, ' ', a.last_name) = p_authorName;
END //
delimiter ;

CALL GetAllBooksByAuthor("John Doe");

-- 
DELIMITER //
CREATE PROCEDURE AddBook(
    IN title VARCHAR(30),
    IN pub_year YEAR,
    IN genre VARCHAR(10),
    IN isbn VARCHAR(13),
    IN price DECIMAL(7,2),
    IN authorId INT,
    IN publisherId INT
)
BEGIN
    INSERT INTO book (title, publication_year, genre, isbn, price, author_id, publisher_id)
    VALUES (title, pub_year, genre, isbn, price, authorId, publisherId);
END //
DELIMITER ;

-- count authors_book
delimiter //
CREATE PROCEDURE CountPublishersBooks(IN p_pubId INT, OUT p_totalBooks INT)
BEGIN
	SELECT COUNT(*) INTO totalBooks
    FROM
		book
	WHERE
		publisher_id = pubId;

END //
delimiter ;

DROP PROCEDURE CountPublishersBooks;

CALL CountPublishersBooks(3, @tbooks);
SELECT @tbooks;

-- previlage sp
GRANT EXECUTE ON PROCEDURE mydb.GetAllBooksByAuthor 
TO
	'reader'@'localhost';

REVOKE EXECUTE ON PROCEDURE mydb.GetAllBooksByAuthor 
FROM
	'reader'@'localhost'; 
    
delimiter //
CREATE PROCEDURE read_book()
SQL SECURITY INVOKER
BEGIN
   SELECT * FROM book;
END //
delimiter ;

DROP PROCEDURE read_book;

GRANT EXECUTE ON PROCEDURE mydb.read_book 
TO
	'reader'@'localhost';

REVOKE SELECT ON mydb.book
FROM
	'reader'@'localhost';

-- Create a procedure AddAuthor that takes first_name and last_name as inputs and inserts into the author table.
delimiter &&
CREATE PROCEDURE AddAuthor(IN p_fname varchar(15), IN p_lname VARCHAR(15))
BEGIN
	INSERT INTO
		author
    SET first_name = p_fname,
    last_name = p_lname;
END &&
delimiter ;

CALL AddAuthor("Steven");

-- Create a procedure GetBookSales with input isbn and 
-- output the total revenue (sum of total_amount) from book_sale.
delimiter //
CREATE PROCEDURE GetBookSales(IN p_isbn VARCHAR(13), OUT p_sales_count INT)
BEGIN
	SELECT count(*) INTO sales_count
    FROM
		book_sale
	GROUP BY
		book_id
	HAVING 
		book_id = p_isbn;
END //
delimiter ;

CALL GetBookSales('9784445556667', @bc);
SELECT @bc;

-- func
DELIMITER //
CREATE FUNCTION GetAuthorName(auth_id INT)
RETURNS VARCHAR(100)
DETERMINISTIC
BEGIN
    DECLARE v_full_name VARCHAR(100);
    SELECT CONCAT(first_name, ' ', last_name) INTO v_full_name
    FROM author
    WHERE author_id = auth_id;
    RETURN v_full_name;
END //
DELIMITER ;

-- Use inside query
SELECT GetAuthorName(2) AS author_name;
































































































-- views
CREATE VIEW book_author_view AS
SELECT b.title, a.first_name
FROM
	book b
INNER JOIN
	author a
ON
	b.author_id = a.author_id;

SELECT first_name from book_author_view;

INSERT INTO book_author_view(title, first_name) VALUES('new one', 'alex');

-- pub avg book price
CREATE VIEW publisher_avg_price_view AS
SELECT p.publisher_name, avg(b.price)
FROM
	publisher p
LEFT OUTER JOIN
	book b
ON
	p.publisher_id = b.publisher_id
GROUP BY
	p.publisher_id;

SELECT * FROM publisher_avg_price_view;

-- security, hiding data
CREATE VIEW public_books_view AS
SELECT title, genre
FROM
	book;
    
GRANT SELECT ON public_books_view
TO
	'reader'@'localhost';

SHOW FULL TABLES WHERE Table_type = "VIEW";

CREATE OR REPLACE VIEW public_books_view AS
SELECT title, price FROM book;

-- Create a view that shows each book’s title, author name, and publisher name.
CREATE VIEW book_author_publisher_view AS
SELECT b.title, p.publisher_name, concat(a.first_name, ' ', a.last_name) as author_name
FROM
	book b
INNER JOIN
	publisher p
ON
	p.publisher_id = b.publisher_id
INNER JOIN
	author a
on
	b.author_id = a.author_id;

DROP VIEW book_author_publisher_view;

SELECT * from book_author_publisher_view;

-- exp book view
CREATE VIEW expensive_book_view AS
SELECT b.title, b.price, p.publisher_name
FROM
	book b
LEFT JOIN
	publisher p
ON
	b.publisher_id = p.publisher_id
WHERE
	b.price > 25;

SELECT * FROM expensive_book_view;

CREATE OR REPLACE VIEW expensive_book_view As
SELECT b.title, b.price, p.publisher_name
FROM
	book b
LEFT JOIN
	publisher p
ON
	b.publisher_id = p.publisher_id
WHERE
	b.price >= 200;

SHOW INDEXES FROM book;

CREATE INDEX idx_genre ON book(genre);

DROP INDEX idx_genre ON book;

explain SELECT * FROM book WHERE genre = 'Mystery';



